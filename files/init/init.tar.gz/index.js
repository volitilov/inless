"use strict";

require('./framework/index.js');