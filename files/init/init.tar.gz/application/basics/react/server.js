export default function(req, res) {
	res.next();
}