
import React from 'react';

export default {
	render() {
		var Yield = this.getYield();
		return (
			<main>
				<Yield />
			</main>
		);
	}
}
