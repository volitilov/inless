
import React from 'react';

export default {
	render() {
		return (
			<main>
				{this.props.children}
			</main>
		);
	}
}
