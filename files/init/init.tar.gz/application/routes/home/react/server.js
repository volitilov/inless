export default function(req, res) {
	res.setData("a", 222);
	res.end();
}
