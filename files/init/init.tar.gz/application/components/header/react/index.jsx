
import React from 'react';
// import comp from 'components';
// var Header = comp('Header');

export default {
	render() {
		return <div className="comp-%name%">Component %name%</div>;
	}
}
