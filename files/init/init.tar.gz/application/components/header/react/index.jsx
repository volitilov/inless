
// import comp from 'components';
// var Header = comp.get('header');

export default {
	render() {
		return <div>Component</div>;
	}
}
