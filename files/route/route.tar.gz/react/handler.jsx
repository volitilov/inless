
import React from 'react/addons';
// import comp from 'components';
// var Header = comp.get('header');

export default {
	render() {
		return <div>Route %name%</div>;
	}
};
