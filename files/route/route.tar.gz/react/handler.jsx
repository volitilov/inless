import React from 'react';
import Store from 'store';
import Link from 'link';
import side from 'side';
import comps from 'components';

// var Any = comps('any');

export default {
	render() {
		return (
			<main role="main">
				<section role="content">
					<h2>%name%</h2>
				</section>
				<aside role="sidebar"></aside>
			</main>
		);
	}
};

