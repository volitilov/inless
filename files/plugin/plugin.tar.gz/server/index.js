export default {
	init(app) {
		console.log("Plugin %name%");
	}
}