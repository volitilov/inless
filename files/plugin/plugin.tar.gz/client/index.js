export default {
	rpc: [],
	init() {
		console.log("Plugin %name%");
	}
}