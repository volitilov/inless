"use strict";
require("babel/register")({
	stage: 0
});
require("./app.js");
