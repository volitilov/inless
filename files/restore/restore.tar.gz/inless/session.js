
var configs = require('configs');
var server = configs('server');
var cookieSession = require('cookie-session');
export default cookieSession({
	name: server.session.name,
	keys: [server.session.secret]
})
