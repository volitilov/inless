"use strict";

require('./.inless/index.js');