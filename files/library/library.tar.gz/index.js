

export default {
	echo(a) {
		return a;
	}
}
