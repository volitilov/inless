
import React from 'react';
import Store from 'store';
import Link from 'link';
import side from 'side';
import comps from 'components';

// var Any = comps('any');

export default {
	render() {
		return <section className="comp-%name%">
			Component %name%
		</section>;
	}
}
