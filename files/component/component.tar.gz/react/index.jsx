
// import comp from 'components';
// var Header = comp.get('header');

export default {
	render() {
		return <div className="comp-%name%">Component %name%</div>;
	}
}
